<?php
/*
 * Plugin Name: WooCommerce Matomo Analytics
 * Description: Accurate WooCommerce Ecommerce tracking for your Matomo
 * Author: InnoCraft
 * Author URI: https://www.innocraft.com
 * Version: 1.0.25
 * Text Domain: woocommerce-piwik-analytics
 * Domain Path: /languages
 * WC requires at least: 2.4.0
 * WC tested up to: 8.2.1
 *
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 * For license details see https://www.innocraft.com/license
 */

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

define('MATOMO_WOOCOMMERCE_ANALYTICS_FILE', __FILE__);

/**
 * @param string $className
 */
function woo_piwik_autoloader($className) {
    $rootNamespace = 'WooPiwik';
    $rootLen = strlen($rootNamespace) + 1; // +1 for namespace separator
    $namespaceSeparator = '\\';

    if (substr($className, 0, $rootLen) === $rootNamespace . $namespaceSeparator) {
        $className = str_replace('.', '', str_replace($namespaceSeparator, DIRECTORY_SEPARATOR, substr($className, $rootLen)));
        require_once 'classes' . DIRECTORY_SEPARATOR . $rootNamespace . DIRECTORY_SEPARATOR . $className . '.php';
    }
}

require_once __DIR__ . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'WooPiwik.php';
spl_autoload_register('woo_piwik_autoloader');

new WooPiwik();
new WooPiwik\Scheduler(__FILE__);
