/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

(function () {
  window.jQuery(document).ready(function ($) {
    function debounce(fn, delayInMs) {
      var timeout;

      return function wrapper() {
        var args = arguments;

        if (timeout) {
          clearTimeout(timeout);
        }

        timeout = setTimeout(() => {
          fn.apply(this, args);
        }, delayInMs || 300);
      };
    }

    if (typeof wooPiwikDiagnosticsAjax !== 'undefined' && wooPiwikDiagnosticsAjax.ajax_url) {
      $('body').on('click', '#woopiwik-lookup-order', function () {
        var button = $(this);
        $.post(wooPiwikDiagnosticsAjax.ajax_url, {
          _ajax_nonce: wooPiwikDiagnosticsAjax.nonce,
          action: 'woopiwik_lookup_order_metadata',
          order_id: $('#woopiwik-lookup-order-id').val(),
        }).done(function (data) {
          $('#woopiwik-lookup-order-results').html(data);
          button.removeClass('is-busy');
        });
      });

      function detectJsTrackerCookieDomains() {
        var PAQ_PUSH_REGEX = /_paq.push\(\s*\[\s*(['"])setCookieDomain\1\s*,\s*(['"])(.*?)\2\s*\]\s*\)/g;
        var DIRECT_CALL_REGEX = /setCookieDomain\(\s*(['"])(.*?)\1\s*\)/g;

        return new Promise(function (resolve, reject) {
          return $.get(wooPiwikDiagnosticsAjax.home_url).done(resolve).fail(reject);
        }).then(function ( data ) {
          var m;
          var domainsFound = [];

          // check for _paq.push
          while ((m = PAQ_PUSH_REGEX.exec(data)) !== null) {
            domainsFound.push(m[3]);
          }

          // check for setCookieDomain(...) calls
          while ((m = DIRECT_CALL_REGEX.exec(data)) !== null) {
            domainsFound.push(m[2]);
          }

          // if no setCookieDomain calls are found, default to current hostname (which is what piwik.js does)
          if (!domainsFound.length && data.indexOf('setCookieDomain') === -1) {
            domainsFound.push(window.location.hostname);
          }

          return domainsFound;
        });
      }

      function checkCookieDomainsMatch() {
        detectJsTrackerCookieDomains().then(function (domains) {
          $('.woopiwik-domain-mismatch-notice').remove();

          if (!domains.length) { // no setCookieDomain calls found
            return;
          }

          var domainToCheck = $('#woopiwik_tracking_cookiedomain').val() || wooPiwikDiagnosticsAjax.detected_cookie_domain;

          if (domains.includes(domainToCheck)) {
            // at least one of the setCookieDomain calls matches what is detected server side
            return;
          }

          var $notice = $('<div>')
            .addClass('notice notice-error woopiwik-domain-mismatch-notice')
            .append(
              $('<p>')
                .append($('<strong>').text('Error:'))
                .append(
                  $('<span>')
                  .css('margin-left', '4px')
                  .append(
                    $('<span>').text('Detected mismatch between configured cookie domain and the domain used in JavaScript tracking code.')
                  )
                  .append('<br/><br/>')
                  .append($('<span>').text('Cookie domains detected on blog: ' + domains.join(', ')))
                  .append('<br/>')
                  .append($('<span>').text('Cookie domain used by WooMatomo: ' + domainToCheck))
                  .append('<br/><br/>')
                  .append(
                    $('<span>').text(
                      'The Cookie Domain field above must match what is used in the \'setCookieDomain\' tracker call exactly.'
                      + ' Enter one of the detected domains above, otherwise ecommerce events will not be attributed to the'
                      + ' correct visits.'
                    )
                  )
                  .append('<br/><br/>')
                  .append(
                    $('<em>Note: setCookieDomain with JavaScript code (for example, <code>_paq.push(["setCookieDomain", mySubdomain + ".mydomain.com"]);</code>) cannot be detected by this diagnostic. This error can sometimes be ignored in this case.</em>'),
                  )
                )
            );

          $('#woopiwik_tracking_cookiedomain')
            .parent()
            .append($notice);
        }).catch(function (e) {
          console.log('Failed to detect JS tracker cookie domains: ' + (e.message || e));
        });
      }

      checkCookieDomainsMatch();

      $('body').on('change', '#woopiwik_tracking_cookiedomain', debounce(checkCookieDomainsMatch));
    }
  });
})();
