/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

(function () {
  window.jQuery(document).ready(function ($) {
    if (typeof wooPiwikDiagnosticsAjax !== 'undefined' && wooPiwikDiagnosticsAjax.ajax_url) {
      $('#woopiwik-lookup-order').on('click', function () {
        var button = $(this);
        $.post(wooPiwikDiagnosticsAjax.ajax_url, {
          _ajax_nonce: wooPiwikDiagnosticsAjax.nonce,
          action: 'woopiwik_lookup_order_metadata',
          order_id: $('#woopiwik-lookup-order-id').val(),
        }).done(function (data) {
          $('#woopiwik-lookup-order-results').html(data);
          button.removeClass('is-busy');
        });
      });
    }
  });
})();
