<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

namespace WooPiwik\Admin;

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

use WooPiwik\Tracking\Tracker;
use WooPiwik;
use WC_Admin_Settings;

if (is_dir(ABSPATH . '/wp-content/plugins/woocommerce/')) {
    include_once ABSPATH . '/wp-content/plugins/woocommerce/includes/admin/settings/class-wc-settings-page.php';
} else if (is_dir(ABSPATH . '/wp-content/mu-plugins/woocommerce/')) {
    include_once ABSPATH . '/wp-content/mu-plugins/woocommerce/includes/admin/settings/class-wc-settings-page.php';
} else {
    include_once __DIR__ . '/../../../../woocommerce/includes/admin/settings/class-wc-settings-page.php';
}

class Settings extends \WC_Settings_Page {

    const FIELD_PIWIK_URL = 'woopiwik_piwik_url';
    const FIELD_PIWIK_IDSITE = 'woopiwik_piwik_idsite';
    const FIELD_TRACKING_ENABLED = 'woopiwik_tracking_enabled';
    const FIELD_PIWIK_TOKEN_AUTH = 'woopiwik_piwik_tokenauth';
    const FIELD_PIWIK_USE_COOKIES = 'woopiwik_piwik_usecookies';
    const FIELD_TRACKING_COOKIE_DOMAIN = 'woopiwik_tracking_cookiedomain';
    const FIELD_LOGGING = 'woopiwik_logging';

    /**
     * Settings are valid if either tracking is not activated, or if tracking is activated and a Matomo IdSite and
     * tracking URL is configured. The tracking URL has to be an actual Matomo URL. Settings are not valid if tracking
     * is activated but tracking URL or idSite is not configured or when the configured tracking URL is not an actual
     * Matomo tracking URL.
     */
    const VALID_SETTINGS = 'woopiwik_settings_valid';

    const INVALID_SETTINGS_REASON = 'woopiwik_settings_invalid_reason';

    const MESSAGE_INVALID_SETTINGS = 'Woo-Matomo is not correctly configured. To fix this error either deactivate tracking or change the Matomo Instance configuration. Details: %s';
    const MESSAGE_INVALID_TOKEN = 'Woo-Matomo is not correctly configured. The authentication token needs to be 32 characters.';

    const TRACKING_ENABLED_VALUE_ONLY_IF_COOKIES = 'only-if-cookies';
    const TRACKING_ENABLED_VALUE_ENABLED = 'yes';
    const TRACKING_ENABLED_VALUE_DISABLED = 'no';

    const NONCE_LOOKUP_AJAX = 'woopiwik-lookup-order-meta';

    /**
     * Init and hook in the integration.
     */
    public function __construct($registerEvents = true) {
        if ($registerEvents) {
            $this->id    = 'woopiwik';
            $this->label = 'Matomo';

            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_PIWIK_URL, array($this, 'sanitizePiwikUrl'), 20, $args = 1);
            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_PIWIK_IDSITE, array($this, 'sanitizePiwikIdSite'), 20, $args = 1);
            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_PIWIK_TOKEN_AUTH, array($this, 'trimTextField'), 20, $args = 1);
            add_filter( 'woocommerce_admin_settings_sanitize_option_' . self::FIELD_TRACKING_COOKIE_DOMAIN, array($this, 'trimTextField'), 20, $args = 1);
            add_action( 'woocommerce_after_settings_woopiwik', [$this, 'output_order_meta_lookup'], $args = 0 );

            add_action( 'admin_enqueue_scripts', [$this, 'admin_enqueue_scripts'] );

            parent::__construct();
        }
    }

    public static function register_ajax() {
        add_action( 'wp_ajax_woopiwik_lookup_order_metadata', [self::class, 'lookup_order_metadata'] );
    }

    public static function lookup_order_metadata() {
        check_ajax_referer( self::NONCE_LOOKUP_AJAX );

        if ( ! wc_current_user_has_role( 'administrator' ) ) {
            echo '<div class="woopiwik-lookup-error">' . esc_html__( 'Unauthorized, must be an admin.', 'woocommerce-piwik-analytics' ) . '</div>';
            die;
        }

        $orderId = wc_sanitize_order_id( wp_unslash( $_POST[ 'order_id' ] ) );

        $order = wc_get_order( $orderId );
        if ( empty( $order ) ) {
            echo '<div class="woopiwik-lookup-error">' . esc_html__( 'Cannot find order.', 'woocommerce-piwik-analytics' ) . '</div>';
            die;
        }

        if ( method_exists($order, 'is_created_via')
            && $order->is_created_via('admin')
        ) {
            echo '<div class="woopiwik-lookup-error">' . esc_html__( 'This order was created through the backoffice. These orders are purposefully ignored when tracking.', 'woocommerce-piwik-analytics' ) . '</div>';
            die;
        }

        $visitorId = WooPiwik\Tracking::get_order_meta($order, WooPiwik\Tracking::META_ORDER_IDVISITOR);
        $userAgent = WooPiwik\Tracking::get_order_meta($order, WooPiwik\Tracking::META_ORDER_USERAGENT);
        $ipAddress = WooPiwik\Tracking::get_order_meta($order, WooPiwik\Tracking::META_ORDER_IPADDRESS);
        $none      = __( 'Nothing set.', 'woocommerce-piwik-analytics' );

        ?>
        <ul>
            <li>
                <strong><?php esc_html_e( 'Visitor ID', 'woocommerce-piwik-analytics' ); ?>:</strong>
                <span class="woopiwik-lookup-visitor-id"><?php echo esc_html( !empty( $visitorId ) ? $visitorId : $none ); ?></span>
            </li>
            <li>
                <strong><?php esc_html_e( 'User Agent', 'woocommerce-piwik-analytics' ); ?>:</strong>
                <?php echo esc_html( !empty( $userAgent ) ? $userAgent : $none ); ?>
            </li>
            <li>
                <strong><?php esc_html_e( 'IP Address', 'woocommerce-piwik-analytics' ); ?>:</strong>
                <?php echo esc_html( !empty( $ipAddress ) ? $ipAddress : $none ); ?>
            </li>
        </ul>
        <?php
        die;
    }

    public function admin_enqueue_scripts() {
        if ( empty( $_GET[ 'page' ] )
            || 'wc-settings' !== $_GET[ 'page' ]
        ) {
            return;
        }

        if ( empty( $_GET[ 'tab' ] )
            || 'woopiwik' !== $_GET[ 'tab' ]
        ) {
            return;
        }

        wp_enqueue_script(
            'woopiwik-diagnostics',
            plugins_url( '/assets/js/diagnostics.js', MATOMO_WOOCOMMERCE_ANALYTICS_FILE ),
            [ 'jquery' ],
            '1.0.0',
            true
        );

        wp_localize_script(
            'woopiwik-diagnostics',
            'wooPiwikDiagnosticsAjax',
            [
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( self::NONCE_LOOKUP_AJAX ),
            ]
        );
    }

    /**
     * Get sections.
     *
     * @return array
     */
    public function get_sections() {
        $sections = array(
            '' => 'Woocommerce Matomo Analytics Options'
        );

        return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
    }

    public function output()
    {
        echo '<h1>WooCommerce Matomo Analytics</h1>';
        echo '<p>' . sprintf(__('Here you can configure the WooCommerce Matomo (formerly Piwik) tracking. When activated, this plugin will track Ecommerce activities such as purchases and cart updates to make sure you have accurate Ecommerce data tracked in your Matomo. To track regular pageviews, outlinks, downloads and more it is still needed to include the Matomo tracking code into your website. For this we recommend using the WP-Matomo/WP-Piwik plugin. %5$sThis plugin is built and maintained by %1$sInnoCraft%2$s, the creators of %3$sMatomo Analytics%4$s. We help our clients get started, configure, monitor and make the most of their Matomo analytics service. We also offer unique analytics products and services that help grow your business and meet the needs of small, medium and large businesses alike.%6$sDon\'t have a Matomo (Piwik) yet? You can either self host Matomo on premise, or take away all the hassle with our %7$sMatomo Analytics Cloud%8$s.', 'woocommerce-piwik-analytics'), '<a href="https://www.innocraft.com">', '</a>', '<a href="https://matomo.org">', '</a>', '<br /><br />', '<br /><br />', '<a href="https://www.innocraft.cloud">', '</a>') . '</p>';

        parent::output();
    }

    public function output_order_meta_lookup() {
        ?>
        <div id="woopiwik-order-meta-lookup">
            <h2><?php esc_html_e( 'Diagnostic Tools', 'woocommerce-piwik-analytics' ); ?></h2>

            <table class="form-table">
                <tbody>
                <tr>
                    <th class="titledesc" scope="row"><?php esc_html_e('Lookup Order Metadata', 'woocommerce-piwik-analytics'); ?></th>
                    <td>
                        <label>
                            <?php esc_html_e('Order Number', 'woocommerce-piwik-analytics'); ?>:<br/>
                            <input type="text" id="woopiwik-lookup-order-id" />
                        </label>
                        <br/>
                        <br/>
                        <button name="save" id="woopiwik-lookup-order" class="woocommerce-save-button components-button is-primary">
                            <?php esc_html_e('Lookup', 'woocommerce-piwik-analytics'); ?>
                        </button>
                        <br/>
                        <br/>
                        <div id="woopiwik-lookup-order-results"></div>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Get settings array.
     *
     * @return array
     */
    public function get_settings() {
        $settings = apply_filters( 'woo_piwik_settings', array(

            array('title' => __('Matomo Instance', 'woocommerce-piwik-analytics'), 'type' => 'title',
                'desc' => __('This section lets you configure the Matomo instance the Ecommerce data should be tracked into. All fields need to be defined.', 'woocommerce-piwik-analytics'),
                'id' => 'woopiwik_piwikinstance_settings' ),

            array(
                'title'       => __('Matomo URL', 'woocommerce-piwik-analytics'),
                'desc'        => __('Enter your Matomo URL. This is the same URL you use to access your Matomo (or Piwik) instance, e.g. https://example.com/matomo/.', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_PIWIK_URL,
                'type'        => 'text',
                'css'         => 'min-width:300px;',
                'placeholder' => 'https://www.example.com/matomo',
                'default'     => '',
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array(
                'title'       => __('Matomo Site ID', 'woocommerce-piwik-analytics'),
                'desc'        => __('Enter the Piwik Site ID for this website. It is an integer, e.g. 1 or 42.', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_PIWIK_IDSITE,
                'type'        => 'text',
                'css'         => 'min-width:300px;',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => '',
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array(
                'title'       => __('Matomo Auth Token', 'woocommerce-piwik-analytics'),
                'desc_tip'    => __('Enter the Matomo Auth-Token of a user with at least Write-access (Admin access if you use Matomo 3.5 or older). It is an alphanumerical code like 0a1b2c34d56e78901fa2bc3d45678efa.', 'woocommerce-piwik-analytics'),
                'desc'        => sprintf(__('See %1$sMatomo FAQ%2$s. The Matomo user needs at least %3$sWrite-access%4$s.', 'woocommerce-piwik-analytics'), '<a href="https://matomo.org/faq/general/faq_114/" target="_blank" rel="noopener noreferrer">', '</a>', '<strong>', '</strong>'),
                'id'          => self::FIELD_PIWIK_TOKEN_AUTH,
                'type'        => 'password',
                'css'         => 'min-width:300px;',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => '',
                'autoload'    => true
            ),

            array('type' => 'sectionend', 'id' => 'woopiwik_piwikinstance_settings'),

            array('title' => __('Tracking', 'woocommerce-piwik-analytics'), 'type' => 'title',
                'desc' => '',
                'id' => 'woopiwik_tracking_settings'),

            array(
                'title'       => __('Enabled', 'woocommerce-piwik-analytics'),
                'desc'        => __('Track Ecommerce orders and cart updates', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_TRACKING_ENABLED,
                'type'        => 'radio',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => 'disabled',
                'options'     => [
                    self::TRACKING_ENABLED_VALUE_DISABLED        => __('Disabled', 'woocommerce-piwik-analytics'),
                    self::TRACKING_ENABLED_VALUE_ENABLED         => __('Enabled', 'woocommerce-piwik-analytics'),
                    self::TRACKING_ENABLED_VALUE_ONLY_IF_COOKIES => __('Only if Matomo tracking cookies are present (select this if you use a consent manager to determine what tracking code to load and run)', 'woocommerce-piwik-analytics'),
                ],
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array(
                'title'       => __('Cookie Domain', 'woocommerce-piwik-analytics'),
                'desc_tip'    => sprintf(__('Needs to be only specified if you use a custom cookie domain in the JavaScript tracker via "%1$s". Usually does not need to be specified. If specified, make sure to specify same domain as specifed via JavaScript.', 'woocommerce-piwik-analytics'), "_paq.push(['setCookieDomain', '...'])"),
                'desc'        => __('Optional', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_TRACKING_COOKIE_DOMAIN,
                'type'        => 'text',
                'css'         => 'min-width:300px;',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => '',
                'autoload'    => true
            ),

            array(
                'title'       => __('Use cookies', 'woocommerce-piwik-analytics'),
                'desc'        => __('Disable if you have cookies disabled in your tracking code to ensure we won\'t set any cookies.', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_PIWIK_USE_COOKIES,
                'type'        => 'checkbox',
                'placeholder' => __( 'N/A', 'woocommerce' ),
                'default'     => 'yes',
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array('type' => 'sectionend', 'id' => 'woopiwik_tracking_settings'),

            array(
                'title' => __('Diagnostics', 'woocommerce-piwik-analytics'),
                'type'  => 'title',
                'desc'  => '',
                'id'    => 'woopiwik_diagnostics_settings',
            ),

            array(
                'title'       => __('Enable Logging', 'woocommerce-piwik-analytics'),
                'desc'        => __('If enabled, logs all tracked data into log files located in "wp-content/uploads/wc-logs".', 'woocommerce-piwik-analytics'),
                'id'          => self::FIELD_LOGGING,
                'type'        => 'checkbox',
                'default'     => true,
                'autoload'    => true,
                'desc_tip'    => true
            ),

            array('type' => 'sectionend', 'id' => 'woopiwik_general_settings'),
        ) );

        return apply_filters('woocommerce_get_settings_' . $this->id, $settings);
    }

    public static function canTrack()
    {
        $trackingEnabled = get_option(self::FIELD_TRACKING_ENABLED);

        if (empty($trackingEnabled)
            || $trackingEnabled === self::TRACKING_ENABLED_VALUE_DISABLED
        ) {
            return false; // tracking disabled
        }

        if ($trackingEnabled === self::TRACKING_ENABLED_VALUE_ONLY_IF_COOKIES
            && self::isMatomoTrackingCookieMissing()
        ) {
            return false; // tracking enabled only if matomo tracker cookies exist, but cookies were not found
        }

        $trackingEnabled = apply_filters('woo_piwik_enable_tracking', true);
        if (empty($trackingEnabled)) {
            return false; // tracking disabled by another wordpress plugin
        }

        return (bool) get_option(self::VALID_SETTINGS, false);
    }

    private static function isMatomoTrackingCookieMissing()
    {
        foreach ($_COOKIE as $name => $value) {
            if (strpos($name, '_pk_id') === 0) {
                return false; // _pk_id cookie found, not missing
            }
        }

        return true;
    }

    public static function hasCookiesEnabled()
    {
        $useCookies = get_option(self::FIELD_PIWIK_USE_COOKIES);

        return $useCookies !== 'no';
    }

    public function save()
    {
        parent::save();
        $this->validate_settings();
    }

    public function validate_settings()
    {
        $url = get_option(self::FIELD_PIWIK_URL);
        $idSite = get_option(self::FIELD_PIWIK_IDSITE);
        $token = get_option(self::FIELD_PIWIK_TOKEN_AUTH);
        $activated = get_option(self::FIELD_TRACKING_ENABLED);

        $invalidSettingReason = null;

        if (!empty($activated) && $activated !== 'no') {
            if (empty($url)) {
                $invalidSettingReason = 'Matomo URL missing';
            } else if (empty($idSite)) {
                $invalidSettingReason = 'Matomo Site ID missing';
            } else if (empty($token) || !is_string($token) || strlen($token) <= 30 || !ctype_alnum($token)) {
                $invalidSettingReason = 'Matomo token auth is invalid';
            }

            if (empty($invalidSettingReason)
                && is_numeric($idSite)
            ) {
                // we only validate token when idSite is numeric, if protectTrackId is used, we assume it is valid as the
                // ping method otherwise won't work
                $tracker = new Tracker();
                $invalidSettingReason = $tracker->ping();
            }

            if (!empty($invalidSettingReason)) {
                update_option(Settings::INVALID_SETTINGS_REASON, $invalidSettingReason);

                if (strlen($token) !== 32) {
                    WC_Admin_Settings::add_error(self::MESSAGE_INVALID_TOKEN);
                } else {
                    WC_Admin_Settings::add_error(sprintf(self::MESSAGE_INVALID_SETTINGS, $invalidSettingReason));
                }
            }
            update_option(self::VALID_SETTINGS, (int) empty($invalidSettingReason), $autoload = true);
        } else {
            update_option(self::VALID_SETTINGS, 1, $autoload = true);
        }
    }

    public function sanitizePiwikUrl($value)
    {
        if (!empty($value) && is_string($value)) {
            $value = trim($value);
            if (strpos($value, '://') === false) {
                $value = 'http://' . $value;
            }
            $value = rtrim($value, '/');
        }

        return $value;
    }

    public function sanitizePiwikIdSite($value)
    {
        if (!empty($value) || $value === '0') {
            return $value;
        }

        return '';
    }

    public function trimTextField($value)
    {
        if (!empty($value) && is_string($value)) {
            $value = trim($value);
            $value = str_replace('&token_auth=', '', $value);
            $value = str_replace('token_auth=', '', $value);
            $value = str_replace('=', '', $value);
        }

        return $value;
    }


}
