<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

namespace WooPiwik;

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

if (!class_exists('\MatomoTracker')) {
    include_once __DIR__ . '/../../libs/piwik-php-tracker/MatomoTracker.php';
}

use WooPiwik\Admin\Settings;
use WooPiwik\Tracking\Tracker;
use WooPiwik;

class Tracking
{
    const PURCHASE_REQUEST_TIMEOUT_IN_SECONDS = 7;
    const CART_UPDATE_REQUEST_TIMEOUT_IN_SECONDS = 3;

    const META_ORDER_TRACKED = '_piwik_tracked';
    const META_ORDER_IDVISITOR = '_piwik_idvisitor';
    const META_ORDER_USERAGENT = '_piwik_useragent';
    const META_ORDER_IPADDRESS = '_piwik_ipaddress';
    const META_ORDER_TRACKING_URL = '_piwik_tracking_url';

    private static $refundDetails = array();

    // on-hold should not be ignored and is valid status... eg for cheque etc
    // we cannot track pending as a payment plugin may redirect to a payment url to fulfill payment
    private $orderStatusIgnore = array('cancelled', 'failed', 'pending', 'refunded');

    public function __construct()
    {
        if (!Settings::canTrack()) {
            return;
        }

        if ($this->isFilteredUserInWpPiwik()) {
            return;
        }

        //add_action('woocommerce_refund_created', array($this, 'collect_refund_details'), 10, 2);

        // those actions are triggered from admin ui
        //add_action('woocommerce_order_partially_refunded', array($this, 'track_partial_refund'), 10, 2);
        //add_action('woocommerce_order_fully_refunded', array($this, 'track_full_refund'), 10, 2);
        // those actions are triggered via REST API
        //add_action('woocommerce_rest_insert_shop_order_refund', array($this, 'track_refund_via_api'), 10, 1);
        add_action('woocommerce_order_status_changed', array($this, 'track_change_order_status'), 10, $params = 3);
        add_action('woocommerce_payment_complete', array($this, 'track_ecommerce_order'));
        add_filter('woocommerce_payment_successful_result', array($this, 'on_successful_payment_result'), $prio = 10, $args = 2);
        add_action('woocommerce_add_to_cart', array($this, 'track_update_cart'), 99999, 0);
        add_action('woocommerce_cart_item_removed', array($this, 'track_update_cart'), 99999, 0);
        add_action('woocommerce_cart_item_restored', array($this, 'track_update_cart'), 99999, 0);
        add_filter('woocommerce_update_cart_action_cart_updated', array($this, 'track_update_cart_updated'), 99999, 1);
        add_action('woocommerce_applied_coupon', array($this, 'track_coupon_update_cart'), 99999, 0);
        add_action('woocommerce_removed_coupon', array($this, 'track_coupon_update_cart'), 99999, 0);
        add_action('woocommerce_after_single_product', [ $this, 'on_product_view' ], 99999, $args = 0);

        // these actions currently just log the status for debugging purposes
        foreach ( wc_get_order_statuses() as $statusId => $statusName ) {
            $statusId = preg_replace('/^wc-/', '', $statusId);
            add_action( 'woocommerce_order_status_' . $statusId, [ $this, 'on_first_order_status' ], 99999, 2 );
        }

        add_action( 'woopiwik_before_tracking_request', [ $this, 'before_tracking_request' ], 99999, 4 );
    }

    /**
     * @param $order_id
     * @param \WC_Order $order
     * @return void
     */
    public function on_first_order_status( $order_id, $order ) {
        $this->log('Order %s gained status %s', [ $order_id, $order->get_status( 'edit' ) ] );
    }

    private function isFilteredUserInWpPiwik()
    {
        // if a user has configured WP-Matomo/WP-Piwik to not track certain roles, we respect this setting as well

        if (!$this->isWpPiwikActive()) {
            return false;
        }

        if (function_exists('is_multisite') && is_multisite()) {
            $key = 'wp-piwik_global-capability_stealth';

            if (self::isPluginActiveForNetwork()) {
                $capabilities = get_site_option($key, array());
            } else {
                $capabilities = get_option($key, array());
            }

            if (!empty($capabilities) && is_array($capabilities)) {
                foreach ($capabilities as $key => $value) {
                    if ($value && current_user_can($key)) {
                        return true;
                    }
                }
            }
        }

        return current_user_can('wp-piwik_stealth');
    }

    private function isWpPiwikActive()
    {
        if (!function_exists('is_plugin_active')) {
            require_once (ABSPATH . 'wp-admin/includes/plugin.php');
        }
        if (function_exists('is_plugin_active')) {
            return is_plugin_active('wp-piwik/wp-piwik.php');
        }
        return false;
    }

    private static function isPluginActiveForNetwork() {
        // see https://codex.wordpress.org/Function_Reference/is_plugin_active_for_network
        if (!function_exists ('is_plugin_active_for_network')) {
            require_once (ABSPATH . 'wp-admin/includes/plugin.php');
        }
        if (function_exists ('is_plugin_active_for_network')) {
            return is_plugin_active_for_network('woocommerce-piwik-analytics/woocommerce-piwik-analytics.php');
        }
        return false;
    }

    public function track_update_cart_updated($cart_updated)
    {
        $this->track_update_cart();
        return $cart_updated;
    }

    private function createTracker()
    {
        return Tracker::makeConfigured();
    }

    /**
     * @param \WC_Product $product
     * @return array
     */
    private function get_product_categories($product)
    {
        $productId = $this->getProductId($product);

        $categoryTerms = get_the_terms($productId, 'product_cat');

        $categories = array();

        if (is_wp_error($categoryTerms)) {
            return $categories;
        }

        if (!empty($categoryTerms)) {
            foreach ($categoryTerms as $category) {
                $categories[] = $category->name;
            }
        }

        $categories = array_unique($categories);
        $categories = array_slice($categories, 0, Tracker::MAX_NUM_ECOMMERCE_ITEM_CATEGORIES);

        return $categories;
    }

    public function track_ecommerce_order($orderId)
    {
        $this->log('New payment complete details for %d', [$orderId]);

        $order = wc_get_order($orderId);
        if (empty($order)) {
            $this->logCannotFindOrder($orderId);
            return;
        }

        if ($this->isOrderFromBackOffice($order)) {
            $this->logOrderFromBackOffice($orderId);
            return;
        }

        if ($this->hasTrackedOrderAlready($order)) {
            $this->log('Ignoring already tracked order %d', [$orderId]);
            return;
        }

        $tracker = $this->createTracker();

        $this->save_order_metadata($order, [
            self::META_ORDER_IDVISITOR => $tracker->getVisitorId(),
            self::META_ORDER_USERAGENT => $tracker->getUserAgent(),
            self::META_ORDER_IPADDRESS => $tracker->getIp(),
        ]);

        $this->log('Order metadata saved for %s', [$orderId]);

        $this->trackOrder($tracker, $orderId);
    }

    /**
     * @param \WC_Order $order
     * @return bool
     */
    private function hasTrackedOrderAlready($order)
    {
        return self::get_order_meta($order, self::META_ORDER_TRACKED) == 1;
    }

    public function on_successful_payment_result($result, $order_id)
    {
        $this->log('on_successful_payment_result fallback');

        // fallback detection of a successfully paid order in case we didn't detect it earlier. This "should" not be needed
        // and we cannot totally rely on this as it is only triggered by checkout and not by other paths.
        $this->track_ecommerce_order($order_id);

        return $result;
    }

    public function track_change_order_status($orderId, $oldStatus, $newStatus)
    {
        $this->log('Status change for ecommerce order %d from %s to %s', [$orderId, $oldStatus, $newStatus]);

        $order = wc_get_order($orderId);
        if (empty($order)) {
            $this->logCannotFindOrder($orderId);
            return;
        }

        if ($this->isOrderFromBackOffice($order)) {
            $this->logOrderFromBackOffice($orderId);
            return;
        }

        if ($this->hasTrackedOrderAlready($order)) {
            $this->log('Ignoring already tracked order %d', [$orderId]);
            return;
        }

        // this might be executed days later by an admin, so we want to re-use the original users'
        // browser etc.
        $visitorId = self::get_order_meta($order, self::META_ORDER_IDVISITOR);
        $userAgent = self::get_order_meta($order, self::META_ORDER_USERAGENT);
        $ipAddress = self::get_order_meta($order, self::META_ORDER_IPADDRESS);

        if (empty($visitorId)) {
            $this->log('Visitor ID was not found in order metadata for order id %d', [$orderId]);
        }

        if (!empty($visitorId)) {
            $tracker = $this->createTracker();
            $tracker->setVisitorId($visitorId);
            if (!empty($userAgent)) {
                $tracker->setUserAgent($userAgent);
            }
            if (!empty($ipAddress)) {
                $tracker->setIp($ipAddress);
            }
            $this->trackOrder($tracker, $orderId);
        } elseif ($oldStatus === 'pending' && $newStatus === 'on-hold') {
            $this->log('payment might not need payment and was set from pending to on-hold');
            // eg for cheque or wire transfer payments
            if (!$order->needs_payment()) {
                $this->log('no payment needed for this order');
                $this->track_ecommerce_order($orderId);
            }
        }
    }

    /**
     * @param \WC_Product $product
     */
    private function getProductId($product)
    {
        if (!$product) {
            return;
        }

        if (WooPiwik::isWC3()) {
            return $product->get_id();
        }

        return $product->id;
    }

    private function trackOrder(Tracker $tracker, $orderId)
    {
        $order = wc_get_order($orderId);
        if (empty($order)) {
            $this->logCannotFindOrder($orderId);
            return;
        }

        if ($this->isOrderFromBackOffice($order)) {
            $this->logOrderFromBackOffice($orderId);
            return;
        }

        if ($this->hasTrackedOrderAlready($order)) {
            $this->log('Ignoring already tracked order %d', [$orderId]);
            return;
        }

        $orderNumberToTrack = $orderId;
        if (method_exists($order, 'get_order_number')) {
            $orderNumberToTrack = $order->get_order_number();
        }

        $orderStatus = $order->get_status();

        $this->log('Order %s with order number %s has status: %s', [$orderId, $orderNumberToTrack, $orderStatus]);

        if (in_array($orderStatus, $this->orderStatusIgnore, $strict = true)) {
            // we won't track it right now but later if the status changes

            $this->log('Ignoring ecommerce order %s because of status: %s. Expecting to track the order after payment completes.', [$orderId, $orderStatus]);

            return;
        }

        $this->log('Beginning track order %s', [$orderId]);

        $items = $order->get_items();
        if ($items) {
            foreach ($items as $itemIndex => $item) {
                /** @var \WC_Order_Item_Product $item */

                $productOrVariation = $this->getItemProduct($order, $item);

                if (is_object($item) && method_exists($item, 'get_product_id')) {
                    // woocommerce 3
                    $productId = $item->get_product_id();
                } else if (isset($item['product_id'])) {
                    // woocommerce 2.x
                    $productId = $item['product_id'];
                } else {
                    continue;
                }

                if (empty($productId)) {
                    $this->log("Unexpected: item %s in order %s does not have a product ID, skipping this item.", [$itemIndex, $orderId]);
                    continue;
                }

                $product = wc_get_product($productId);
                if (empty($product)) {
                    $this->log("Failed to get product with ID %s for order %s, skipping this item.", [$productId, $orderId]);
                    continue;
                }

                if ($productOrVariation && $productOrVariation->get_sku()) {
                    $sku = $productOrVariation->get_sku();
                } else {
                    $sku = $this->getProductId($productOrVariation);
                }

                $price = $order->get_item_total($item);
                $title = $product->get_title();
                $cats = $this->get_product_categories($product);
                $quantity = $item['qty'];
                try {
                    $tracker->addEcommerceItem($sku, $title, $cats, $price, $quantity);
                } catch (\Exception $e) {
                    $this->log('Failed to add ecommerce item: %s (error = %s)', [$title, $e->getMessage()]);
                }
            }
        }

        $tracker->setRequestTimeout(self::PURCHASE_REQUEST_TIMEOUT_IN_SECONDS);
        try {
            $tracker->doTrackEcommerceOrder(
                $orderNumberToTrack,
                $order->get_total(),
                $order->get_subtotal(),
                $order->get_cart_tax(),
                WooPiwik::isWC3() ? $order->get_shipping_total() : $order->get_total_shipping(),
                $order->get_total_discount()
            );
        } catch ( \Exception $ex ) {
            $this->log( 'Failed to track ecommerce order: %s. URL was: %s', [ $ex->getMessage(), \MatomoTracker::$DEBUG_LAST_REQUESTED_URL ] );
            return;
        }

        $this->log('Tracked ecommerce order %s with number %s: %s', [$orderId, $orderNumberToTrack, \MatomoTracker::$DEBUG_LAST_REQUESTED_URL]);

        $this->save_order_metadata($order, [
            self::META_ORDER_TRACKED => 1,
            self::META_ORDER_TRACKING_URL => \MatomoTracker::$DEBUG_LAST_REQUESTED_URL,
        ]);
    }

    /**
     * @param \WC_Order $order
     * @param $item
     * @return mixed
     */
    private function getItemProduct($order, $item)
    {
        $productOrVariation = false;
        if (WooPiwik::isWC3() && !empty($item) && is_object($item) && method_exists($item, 'get_product') && is_callable(array($item, 'get_product'))) {
            $productOrVariation = $item->get_product();
        } else if (method_exists($order, 'get_product_from_item')) {
            // eg woocommerce 2.x
            $productOrVariation = $order->get_product_from_item($item);
        }

        return $productOrVariation;
    }

    public function track_update_cart()
    {
        $this->_track_update_cart(false);
    }

    public function track_coupon_update_cart()
    {
        $this->_track_update_cart(true);
    }

    /**
     * Sends cart update request
     */
    public function _track_update_cart($isCouponUpdate)
    {
        global $woocommerce;

        $tracker = $this->createTracker();

        /** @var \Wc_Cart $cart */
        $cart = $woocommerce->cart;
        if (!$isCouponUpdate) {
            // can cause cart coupon not to be applied when woocomerce subscriptions is used.
            $cart->calculate_totals();
        }
        $cart_content = $cart->get_cart();

        foreach ($cart_content as $item) {
            /** @var \WC_Product $product */
            $product = wc_get_product($item['product_id']);

            if (WooPiwik::isWC3()) {
                $productOrVariation = $product;

                if (!empty($item['variation_id'])) {
                    $variation = wc_get_product($item['variation_id']);
                    if (!empty($variation)) {
                        $productOrVariation = $variation;
                    }
                }
            } else {
                $order = new \WC_Order(null);
                $productOrVariation = $order->get_product_from_item($item);
            }

            if (empty($productOrVariation)) {
                continue;
            }

            if ($productOrVariation && $productOrVariation->get_sku()) {
                $sku = $productOrVariation->get_sku();
            } else {
                $sku = $this->getProductId($productOrVariation);
            }

            $price = 0;
            if (isset($item['line_total'])) {
                $total = floatval($item['line_total']) / max(1, $item['quantity']);
                $price = round( $total, wc_get_price_decimals() );
            }

            $title = $product->get_title();
            $categories = $this->get_product_categories($product);
            $quantity = isset($item['quantity']) ? $item['quantity'] : 0;
            $tracker->addEcommerceItem($sku, $title, $categories, $price, $quantity);
        }

        $tracker->setRequestTimeout(self::CART_UPDATE_REQUEST_TIMEOUT_IN_SECONDS);

        $total = 0;
        if (!empty($cart->total)) {
            $total = $cart->total;
        } elseif (!empty($cart->cart_contents_total)) {
            $total = $cart->cart_contents_total;
        }

        try {
            $tracker->doTrackEcommerceCartUpdate($total);
        } catch ( \Exception $ex ) {
            $this->log( "Failed to track ecommerce cart update: %s. URL was: %s", [ $ex->getMessage(), \MatomoTracker::$DEBUG_LAST_REQUESTED_URL ] );
            return;
        }

        $this->log('Tracked ecommerce cart update for order: %s', [\MatomoTracker::$DEBUG_LAST_REQUESTED_URL]);
    }

    private function log($message, $params = [])
    {
        $logging = get_option(Settings::FIELD_LOGGING);

        if (!empty($logging) && $logging !== 'no') {
            $handle = 'woo-matomo-tracking-' . date("Y-m-d");

            if (function_exists('wc_get_logger')) {
                $log = wc_get_logger();
            } else {
                $log = new \WC_Logger();
            }

            if (!empty($message) && is_string($message)) {
                $message = vsprintf($message, $params);

                $token = get_option(Settings::FIELD_PIWIK_TOKEN_AUTH);
                if (!empty($token) && is_string($token)) {
                    $message = str_replace('token_auth=' . $token, 'token_auth=XYZANONYMIZED', $message);
                }
            }

            $log->add($handle, $message);
        }
    }

    /**
     * @param \WC_Order|\WC_Order_Refund $order
     * @return bool
     */
    private function isOrderFromBackOffice($order)
    {
        // for recent versions of woocommerce (4.0+) use is_created_via(), otherwise default to is_admin() (which will provide false positives
        // when using a theme that uses admin-ajax.php to add orders)
        return method_exists($order, 'is_created_via') ? $order->is_created_via('admin') : is_admin();
    }

    /*
     * @param \WC_Order $order
     * @param $name
     * @return mixed
     */
    public static function get_order_meta($order, $name)
    {
        if (method_exists($order, 'get_meta')) {
            return $order->get_meta($name);
        } else {
            $id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
            return get_post_meta($id, $name, true);
        }
    }

    /**
     * @param \WC_Order $order
     * @param array $metadata
     * @return void
     */
    private function save_order_metadata($order, $metadata)
    {
        foreach ($metadata as $name => $value) {
            if (method_exists($order, 'update_meta_data')) {
                $order->update_meta_data($name, $value);
            } else {
                $id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
                update_post_meta($id, $name, $value);
            }
        }

        if (method_exists($order, 'save')) {
            $order->save();
        }
    }

    public function on_product_view()
    {
        /** @var WC_Product $product */
        global $product;

        if (empty($product)) {
            return;
        }

        if ((defined('DOING_AJAX') && DOING_AJAX)
            || (defined('REST_REQUEST') && REST_REQUEST)
        ) { // sanity check
            return;
        }

        if (is_admin()) {
            return;
        }

        $params = [
            'setEcommerceView',
            $this->get_sku($product),
            $product->get_title(),
            $this->get_product_categories($product),
            $product->get_price(),
        ];
        $params = json_encode($params);

        // we're not using wc_enqueue_js eg to prevent sometimes this code from being minified on some JS minifier plugins
        echo '<script>window._paq = window._paq || []; window._paq.push(' . $params . ');</script>';
    }

    /**
     * @param WC_Product $product
     */
    private function get_sku($product)
    {
        if ($product && $product->get_sku()) {
            return $product->get_sku();
        }

        return $this->get_product_id($product);
    }

    /**
     * @param WC_Product $product
     */
    private function get_product_id($product)
    {
        if (!$product) {
            return;
        }

        if (WooPiwik::isWC3()) {
            return $product->get_id();
        }

        return $product->id;
    }

    private function logCannotFindOrder($orderId)
    {
        $this->log('Unexpected: cannot find order for order ID = %s', [$orderId]);
    }

    private function logOrderFromBackOffice($orderId)
    {
        $this->log('Order %s detected as created manually through the backoffice, skipping tracking.', [$orderId]);
    }

    public function before_tracking_request( $url, $method, $data, $force )
    {
        $this->log( "WooMatomo starting tracking request %s %s", [ $url, $method ] );
    }
}
