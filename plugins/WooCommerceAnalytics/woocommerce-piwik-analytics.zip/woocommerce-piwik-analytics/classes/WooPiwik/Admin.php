<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

namespace WooPiwik;

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

use WooPiwik\Admin\Settings;

class Admin
{
    public function __construct()
    {
        add_action('init', function () {
            if (!\WooPiwik::isWooInstalled()) {
                return;
            }

            add_filter('woocommerce_get_settings_pages', array($this, 'addWoocommerceSettings'));

            if (empty($_POST) && !get_option(Settings::VALID_SETTINGS, true)) {
                add_action('admin_notices', array($this, 'addErrorIfInvalidConfig'));
            }
        });
    }

    public function addErrorIfInvalidConfig()
    {
        $errorMessage = sprintf(Settings::MESSAGE_INVALID_SETTINGS, get_option(Settings::INVALID_SETTINGS_REASON, 'Unknown'));
        echo '<div class="error woo-piwik-not-configured-message"><p>' . __($errorMessage, 'woocommerce-piwik-analytics') .'</p></div>';
    }

    public function addWoocommerceSettings($settings) {
        $settings[] = new Settings();
        return $settings;
    }
}
