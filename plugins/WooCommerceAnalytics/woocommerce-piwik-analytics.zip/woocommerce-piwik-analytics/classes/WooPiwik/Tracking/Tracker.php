<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

namespace WooPiwik\Tracking;

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

use WooPiwik\Admin\Settings;

if (!class_exists('\MatomoTracker')) {
    include_once __DIR__ . '/../../../libs/piwik-php-tracker/MatomoTracker.php';
}

class Tracker extends \MatomoTracker
{
    private $hasCookie = false;

    public function __construct()
    {
        $idSite = get_option(Settings::FIELD_PIWIK_IDSITE);
        $url = get_option(Settings::FIELD_PIWIK_URL);
        $token = get_option(Settings::FIELD_PIWIK_TOKEN_AUTH);

        parent::__construct($idSite, $url);

        if (!empty($token)) {
            $this->setTokenAuth($token);
        }

		if (Settings::hasCookiesEnabled()) {
			$domain = get_option(Settings::FIELD_TRACKING_COOKIE_DOMAIN, $default = '');
			if (empty($domain)) {
				$domain = wp_parse_url(home_url(), PHP_URL_HOST);
			}
			$this->enableCookies($domain);
		}

        if ($this->loadVisitorIdCookie()) {
            if (!empty($this->cookieVisitorId)) {
                $this->hasCookie = true;
                $this->setVisitorId($this->cookieVisitorId);
            }
        }
    }

    protected function setCookie($cookieName, $cookieValue, $cookieTTL)
    {
        if (!$this->hasCookie) {
            // we only set / overwrite cookies if it is a visitor that has eg no JS enabled or ad blocker enabled etc.
            // this way we will track all cart updates and orders into the same visitor on following requests.
            // If we recognized the visitor before via cookie we want in our case to make sure to not overwrite
            // any cookie
            parent::setCookie($cookieName, $cookieValue, $cookieTTL);
        }
    }

    /**
     * Sends a simple request to the Piwik Reporting API to test whether the configured Piwik URL, idSite and token is valid.
     * It won't actually track any data, only test whether the configured tracking URL looks valid.
     *
     * @return string|null `null` if it worked, an error message if it didn't
     */
    public function ping()
    {
        $errorMessage = $this->pingMethod('getSitesIdWithWriteAccess');
        if (empty($errorMessage)) {
            return null;
        }

        // pre Matomo 3.6
        $errorMessagePre36 = $this->pingMethod('getSitesIdWithAdminAccess');
        if (empty($errorMessagePre36)) {
            return null;
        }

        // try to return the most relevant error message
        $looksLikeMethodNotFoundError = strpos($errorMessage, 'does not exist or is not available');
        return $looksLikeMethodNotFoundError ? $errorMessagePre36 : $errorMessage;
    }

    private function pingMethod($method)
    {
        $url = self::$URL;

        if (strpos($url, '.php') !== false) {
            $url = dirname(self::$URL); // eg if user specified piwik.php in the URL we need to remove it
        }
        $url .= '/index.php?module=API&method=SitesManager.' . $method . '&format=json';

        $response = $this->sendApiRequest($url, array('token_auth' => $this->token_auth));

        if (empty($response)) {
            return 'Matomo API could not be reached';
        }

        $response = json_decode($response, true);
        if (!empty($response['result']) && $response['result'] === 'error') {
            return 'Matomo API experienced an error: ' . ($response['message'] ?? 'no error message provided');
        }

        if (is_numeric($this->idSite)) {
            if (is_array($response) && in_array($this->idSite, $response)) {
                return null;
            } else {
                return 'The user for the given token_auth does not have appropriate access to the configured site (ID = ' . $this->idSite . ')';
            }
        }

        // eg when using protect site id... we won't know if user actually has access to that site but we simply
        // have to assume it's correct
        if (empty($response) || !is_array($response)) {
            return 'invalid response from Matomo API, expected array, got ' . gettype($response);
        }

        return null;
    }

    private function sendApiRequest($url, $data)
    {
        $data = http_build_query($data);

        $content = '';

        if (function_exists('curl_init') && function_exists('curl_exec')) {
            $options = array(
                CURLOPT_URL => $url,
                CURLOPT_USERAGENT => $this->userAgent,
                CURLOPT_HEADER => true,
                CURLOPT_TIMEOUT => $this->requestTimeout,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => array(
                    'Accept-Language: ' . $this->acceptLanguage,
                ),
            );

            if (defined('PATH_TO_CERTIFICATES_FILE')) {
                $options[CURLOPT_CAINFO] = PATH_TO_CERTIFICATES_FILE;
            }

            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = $data;

            $ch = curl_init();
            curl_setopt_array($ch, $options);
            ob_start();
            $response = @curl_exec($ch);
            ob_end_clean();
            $content = '';
            if (!empty($response)) {
                list($header, $content) = explode("\r\n\r\n", $response, $limitCount = 2);
            }

        } elseif (function_exists('stream_context_create')) {
            $stream_options = array(
                'http' => array(
                    'method' => 'POST',
                    'user_agent' => $this->userAgent,
                    'header' => "Accept-Language: " . $this->acceptLanguage . "\r\n",
                    'timeout' => $this->requestTimeout, // PHP 5.2.1
                ),
            );

            $stream_options['http']['content'] = $data;

            $ctx = stream_context_create($stream_options);
            $response = file_get_contents($url, 0, $ctx);
            $content = $response;
        }

        return $content;
    }

    protected function sendRequest( $url, $method = 'GET', $data = null, $force = false ) {
        do_action( 'woopiwik_before_tracking_request', $url, $method, $data, $force );
        return parent::sendRequest( $url, $method, $data, $force );
    }
}
