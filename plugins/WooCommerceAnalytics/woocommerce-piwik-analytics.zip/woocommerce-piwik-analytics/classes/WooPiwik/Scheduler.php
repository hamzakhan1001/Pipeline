<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

namespace WooPiwik;

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

use WooPiwik\Admin\Settings;

class Scheduler
{
    const EVENT_VALIDATE_CONFIG = 'woopiwik_validate_configuration';

    public function __construct($pluginFile)
    {
        add_action(self::EVENT_VALIDATE_CONFIG, array($this, 'validateConfiguration'));
        add_action('init', array($this, 'registerEvents'));
        register_deactivation_hook($pluginFile, array($this, 'unregisterEvents'));
    }

    function unregisterEvents()
    {
        $timestamp = wp_next_scheduled(self::EVENT_VALIDATE_CONFIG);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::EVENT_VALIDATE_CONFIG);
        }
    }

    public function registerEvents()
    {
        if (!wp_next_scheduled(self::EVENT_VALIDATE_CONFIG)) {
            wp_schedule_event(time(), 'daily', self::EVENT_VALIDATE_CONFIG);
        }
    }

    public function validateConfiguration()
    {
        $settings = new Settings($registerEvents = false);
        $settings->validate_settings();
    }

}