<?php
/**
 * Copyright (C) InnoCraft Ltd - All rights reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
 * The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
 * Redistribution of this information or reproduction of this material is strictly forbidden
 * unless prior written permission is obtained from InnoCraft Ltd.
 *
 * You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
 *
 * @author InnoCraft
 * @copyright https://www.innocraft.com
 * @link https://www.innocraft.com/
 * @license For license details see https://www.innocraft.com/license
 */

if (!defined( 'ABSPATH')) {
    exit; // if accessed directly
}

use WooPiwik\Tracking;
use WooPiwik\Admin;

class WooPiwik {

    public static function isWooInstalled()
    {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once( ABSPATH . '/wp-admin/includes/plugin.php' );
        }

        return is_plugin_active('woocommerce/woocommerce.php');
    }

    public function __construct() {
        $this->declareWoocommerceHposCompatible();

        new Admin();

        add_action( 'init', function ()  {
            if (self::isWooInstalled()) {
                new Tracking();
            }
        });
        $this->updateCheck();

        \WooPiwik\Admin\Settings::register_ajax();
    }

    public static function isWC3()
    {
        global $woocommerce;
        $result = version_compare($woocommerce->version, '3.0', '>=');
        return $result;
    }

    public function updateCheck()
    {
        $piwikUrl = get_option('woopiwik_piwik_url');

        if (!empty($piwikUrl)) {
            $piwikUrl = trim($piwikUrl);

            if (strpos($piwikUrl, '//') === 0) {
                $piwikUrl .= 'https://' . $piwikUrl;
            }

            if (strpos($piwikUrl, 'http') === 0) {

                $piwikUrl = str_replace(array('piwik.php', 'tracker.php', 'index.php'), '', $piwikUrl);

                if (substr($piwikUrl, -4) === '.php') {
                    $piwikUrl = dirname($piwikUrl); // in case custom tracker is used
                }

                if (substr($piwikUrl, -1) !== '/') {
                    $piwikUrl .= '/';
                }

                $piwikUrl .= 'index.php?module=WooCommerceAnalytics&action=pluginUpdate';

                require dirname(__FILE__) . '/../plugin-update-checker/plugin-update-checker.php';

                Puc_v4_Factory::buildUpdateChecker(
                    $piwikUrl,
                    MATOMO_WOOCOMMERCE_ANALYTICS_FILE,
                    'woocommerce-piwik-analytics'
                );
            }
        }

    }

    private function declareWoocommerceHposCompatible() {
        add_action(
            'before_woocommerce_init',
            function() {
                if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
                    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', 'woocommerce-piwik-analytics/woocommerce-piwik-analytics.php', true );
                }
            }
        );
    }
}
