=== WooCommerce Matomo Analytics ===
Contributors: InnoCraft.com
Tags: piwik,analytics,tracking,ecommerce
Requires at least: 4.6

Accurate WooCommerce Ecommerce tracking for your Piwik

== Description ==
Sends tracking requests for Ecommerce purchases, cart updates and refunds. These requests will be sent from your server instead of via JavaScript to also track purchases when your customers have JavaScript disabled or when they use an ad blocker.

It also make sure to only track cart updates when there were actually changes so you got more insights into abandoned carts in the ecommerce log.

* An order in Woocommerce is recorded as an ecommerce order in Piwik as soon as the payment completes. If the order payment doesn't complete, or when the order fails or is cancelled, Piwik will show an Ecommerce Abandoned cart. 
* Any order with the status of "Pending" or "On-hold" would be tracked when the order does not require a payment (such as for check, cash on pickup, or wire transfer payments).
* Any order with a status of "Cancelled" or "Failed" are not tracked as Ecommerce orders and discarded. 
* Supports WPML: measure each of your site analytics in its own Piwik website.

Known issue: It currently may create once a new visitor as soon as a cart is updated. If this is the case, all following pageviews and actions will be tracked into the newly created visitor. This happens for example when a user visited your shop in the past, deletes all the cookies and then visits your shop again. It may also happen when opening the website in an "Igncognito window" in your browser. We will be solving this issue in Piwik itself.


== Installation ==
* Install the plugin
* Go to WooCommerce => Settings => Piwik
* Configure your Piwik instance and activate tracking

You will still need a plugin do track regular pageviews, outlinks, downloads and more. We recommend to use this plugin in combination with WP-Matomo/WP-Piwik.

To configure this plugin, go to WooCommerce => Settings => Piwik. Configure your Piwik instance and press "Activate tracking".

== License & Copyright ==
Copyright (C) InnoCraft Ltd - All rights reserved.

NOTICE:  All information contained herein is, and remains the property of InnoCraft Ltd.
The intellectual and technical concepts contained herein are protected by trade secret or copyright law.
Redistribution of this information or reproduction of this material is strictly forbidden
unless prior written permission is obtained from InnoCraft Ltd.

You shall use this code only in accordance with the license agreement obtained from InnoCraft Ltd.
For license details see https://www.innocraft.com/license
